#ifndef _pblmi_h_
#define _pblmi_h_

#include <wtypes.h>
// PbLMI interfaces

// LMI method result codes
enum PBLMI_Result
{
   PBLMI_OK,
   PBLMI_ERROR,
   PBLMI_BADFORMAT,
   PBLMI_ABORT,
	PBLMI_NOTFOUND
};

enum PBLMI_CodePage
{
   PBLMI_WIDE,
   PBLMI_ANSI,
   PBLMI_OEM,
	PBLMI_UTF8
};

struct PBL_ENTRYINFO
{
   char  *entry_name;   // pointer to entry name 
   DWORD data_len;      // data length including comments
   WORD  comment_len;   // comments are stored at the beginning of the data
   DWORD mod_time; // entry time 
   //BYTE   internal_data[?];
   DWORD node;
	DWORD data_offset;
	DWORD entry_offset;
};
// forward declarations
struct IPBLMI_Callback;
struct IPBLMI_PBL;
struct PBL_ENTRYINFO;

struct IPBLMI
{
   // create library
   virtual PBLMI_Result CreateLibrary(const char *szLib) = 0;

   // open library and return IPBLMI_PBL interface to misc. LMI functions
   virtual IPBLMI_PBL* OpenLibrary(const char *szLib, BOOL bReadWrite = FALSE) = 0;

   // close library opened by OpenLibrary
//   virtual PBLMI_Result CloseLibrary(IPBLMI_PBL *iPbl) = 0;

   // call this method to release IPBLMI interface
   // and delete underlying object
   virtual void Release(void) = 0;
	
	// set output encoding for strings
   virtual PBLMI_Result SetTargetCodePage(PBLMI_CodePage cp) = 0;
	// get output encoding
   virtual PBLMI_CodePage GetTargetCodePage() = 0;
};



struct IPBLMI_PBL
{
   virtual PBLMI_Result Dir(IPBLMI_Callback *iCallBack) = 0;
   virtual PBLMI_Result SeekEntry(const char *szEntryName, PBL_ENTRYINFO * pEntry, BOOL bCreate = FALSE) = 0;
   virtual PBLMI_Result DeleteEntry(PBL_ENTRYINFO *pEntry) = 0;
   virtual PBLMI_Result ReadEntryData(PBL_ENTRYINFO *pEntry, void * pBuf) = 0;
   virtual PBLMI_Result SetEntryTime(PBL_ENTRYINFO *pEntry) = 0;
   virtual PBLMI_Result UpdateEntryData
   (
      PBL_ENTRYINFO *pEntry, 
      const BYTE *pData, 
      DWORD dwDataLen, 
      const BYTE *pComments, 
      WORD wComLen
   ) = 0;
   virtual void Close(void) = 0;
   virtual BOOL isUnicode() = 0;

};

struct IPBLMI_Callback
{
   virtual BOOL DirCallback(PBL_ENTRYINFO *pEntry) { return TRUE;}
};


struct Ent {
	char * name; 
	int offset; // -1 - curr entry, -2 - deleted entries
	static int __cdecl cmp (Ent *a, Ent *b) { // for qsort
		return 0;
	}
	static int __cdecl cmprev (Ent *a, Ent *b) { // for qsort
		return cmp(b, a);
	}
};

#endif
