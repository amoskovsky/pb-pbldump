
#include "classes.h"
#include "debug.h"




PBLMI_Result 
PBLMI_PBL::SeekEntry(const char *szEntryName, PBL_ENTRYINFO * pEntry, BOOL bCreate) {
	pEntry->entry_name = NULL;
	PBLMI_Result ret = this->SeekEntry(szEntryName, pEntry, bCreate, m_StartOffset + m_RootNodeOffset);
	if (pEntry->entry_name) {
		delete [] pEntry->entry_name;
		pEntry->entry_name = NULL;
	}
	return ret;
}

int PBLMI_PBL::StrCmp (const void * s1, const void * s2) 
{
	if (m_bUTF)
		return wcsicmp((const wchar_t*)s1, (const wchar_t*)s2);
	else
		return stricmp((const char*)s1, (const char*)s2);
}
PBLMI_Result 
PBLMI_PBL::SeekEntry(const char *szEntryName, PBL_ENTRYINFO * pEntry, BOOL bCreate, DWORD dwNode)
{
//   my ($me, $entry, $create, $nod) = @_;
   // � Perl $create - ref to array [0, 0, 0, 0] 
	// ��� ��������� �������� �� ��������� ��� ENT*
	// � C++ ��� ������ bool, � �������� ���������� � pEntry
   
   //$nod = $$me[$StartOffset] + 0x200 + $FreeBlockSize if !defined $nod;
	if (! dwNode)
		return PBLMI_NOTFOUND;
	if( szEntryName) {
		int name_len = strlen(szEntryName);
		if (m_bUTF) {
			pEntry->entry_name =  MultiToWide(szEntryName, 
														 name_len, 
														 CP_ACP);
		}
		else {
			// see delete in SeekEntry(other)
			pEntry->entry_name = new char[name_len + 1];
			strcpy(pEntry->entry_name, szEntryName);
		}
	}
//	PBLMI_CodePage l_TgtCp = m_iPbLMI->GetTargetCodePage();
/*
   int entry_len;
   entry_len = name_len + Get1(EntFixedLen) + 1;
	if (entry_len > NodeSize - NodeEntOffset)
		return PBLMI_NOTFOUND;
*/
	PBL_NOD nod;
   fseek(m_Handle, dwNode, SEEK_SET);
	fread(&nod, sizeof(nod), 1, m_Handle);
	if (strncmp(nod.sign, "NOD*", 4))
		return PBLMI_BADFORMAT;
	//pf("left: 0x%08X  right: 0x%08X", nod.left, nod.right);   
   
	
   //my ($first_name, $last_name);
	ByteBuffer first_name, last_name;
	
   if (nod.ent_count)
   {
		WORD li_nlen;
		fseek(m_Handle, dwNode + nod.first_offset - 2, SEEK_SET);
		fread(&li_nlen, sizeof(li_nlen), 1, m_Handle);
		first_name.Read(m_Handle, li_nlen);
      if ( StrCmp((char*)first_name.buffer(),  pEntry->entry_name)> 0)
      {
			// !!! not impl
			/*
         if (bCreate && !nod.left && nod.free_space < entry_len)
         {
            nod.left = this->CreateNode(dwNode);
				if (!nod.left)
					return PBLMI_ERROR;
				fseek(m_Handle, dwNode + NodeLeftOffset, SEEK_SET);
				fwrite(&nod.left, sizeof(nod.left), 1, m_Handle);
			
         }
			*/
			if (nod.left)
				return this->SeekEntry(NULL, pEntry, bCreate, nod.left);
			if (!bCreate)
				return PBLMI_NOTFOUND;
         // add to current node (w/o check for space)
			
			// !!! not impl
			/*
         return this->AddEntryToNode(
            szEntryName, pEntry, 1, 0, dwNode, nod.free_space, 
            nod.last_offset, nod.ent_count, nod.first_offset
         );
			*/
			return PBLMI_NOTFOUND;
      }

		fseek(m_Handle, dwNode + nod.last_offset - 2, SEEK_SET);
		fread(&li_nlen, sizeof(li_nlen), 1, m_Handle);
		last_name.Read(m_Handle, li_nlen);
      if ( StrCmp((char*)last_name.buffer(),  pEntry->entry_name) < 0)
      {
			// !!! not impl
			/*         if (bCreate && !nod.right && nod.free_space < entry_len)
         {
            nod.right = this->CreateNode(dwNode);
				if (!nod.right)
					return PBLMI_ERROR;
				fseek(m_Handle, dwNode + NodeLeftOffset, SEEK_SET);
				fwrite(&nod.right, sizeof(nod.right), 1, m_Handle);
			
         }
			*/
			if (nod.right)
				return this->SeekEntry(NULL, pEntry, bCreate, nod.right);
			if (!bCreate)
				return PBLMI_NOTFOUND;
         // add to current node (w/o check for space)
			// !!! not impl
			/*
         return this->AddEntryToNode(
            szEntryName, pEntry, 1, 0, dwNode, nod.free_space, 
            nod.last_offset, nod.ent_count, nod.first_offset
         );
			*/
			return PBLMI_NOTFOUND;
      }
   }  
	// the entry is in this node
	//print "loop\n";
	ByteBuffer buf;
	buf.Read(
		m_Handle, 
		NodeSize - NodeEntOffset - nod.free_space, 
		dwNode + NodeEntOffset
	);
   //my @names;
	
   //@names = (1 .. $ent_count*2 + 2) if $create;
//	Array<Ent> names(bCreate ? nod.ent_count + 1 : 0);
	PBL_ENT *pent;
	PBL_ENT_W *pent_W;
   for (int offset = 0, ent_num = 0; ent_num < nod.ent_count ; ent_num ++)
   {
      //my ($name_len = unpack "S", substr($buf, $offset + $EntFixedLen - 2, 2);
		if (m_bUTF) {
			pent_W = (PBL_ENT_W *) (buf.buffer() + offset);
		}
		else {
			pent = (PBL_ENT *) (buf.buffer() + offset);
		}

		//pent_W = (PBL_ENT_W *)pent;  
		if (GetPF(pent, entry_name_len) == 0 || 
			 GetPF(pent, entry_name_len) > 16000) {
			//	 return undef if $name_len <= 0;
			return PBLMI_BADFORMAT;
		}
		char * cur_name = (char*)buf.buffer() + offset + Get1(EntFixedLen);
      if (!StrCmp(cur_name, pEntry->entry_name))
      {
         /*
			my ($data_offset, $data_len, $entry_time, $comment_len) =
            unpack "LLLS", substr($buf, $offset + 8, 14);
         return [
            $data_offset, $data_len, $entry_time, $comment_len,
            $nod,
            $nod + $NodeEntOffset + $offset
         ];
			*/
			if(m_bUTF)
				pent_W->comment_len *= 2;
			pEntry->comment_len = GetPF(pent, comment_len);
			pEntry->data_len = GetPF(pent, data_len);
			pEntry->mod_time = GetPF(pent, creation_time.tm);
			pEntry->node = dwNode;
			pEntry->data_offset = GetPF(pent, data_offset);
			pEntry->entry_offset = dwNode + NodeEntOffset + offset;
			return PBLMI_OK;
			
      }
		/*
      if (bCreate)
      {
         names[ent_num].name = cur_name;
			names[ent_num].offset = offset;
      }
		*/
      offset += Get1(EntFixedLen) + GetPF(pent, entry_name_len);   
   }
	if (!bCreate)
		return PBLMI_NOTFOUND;
   
	// ������ ��� �� �����������
/* 	
	//add entry
   if (nod.free_space >= entry_len)
   {
      return this->AddEntryToNode(
         pEentry, 0, 0,  $nod, $free_space,
         $last_offset, $ent_count, $first_offset
      );
      
   }else
   {
      names[nod.ent_count].name = szEntryName;
      names[nod.ent_count].offset = -1; //����� �������������
      
		//$buf .= 'ENT*' . $$me[$PbSign] .
      //   pack ("LLLSS", @$create, length($entry) + 1) .
      //      $entry . chr(0);
      nod.free_space -= entry_len; //# ����� ������ �.�. < 0
      nod.ent_count ++;
		//???
      //my %names = @names; // ???
///*
   �������� ����� ������ ��� �������� ����������
   �� �������� �������� (��� ������������ ������������ ������)
   
   � ���������� �������� ����������� ������ 2/3 (��������������� ����������
   ����������� �����) ���� �� ��� ��������
   ��� ������� � ��������� ����������� ���
// *     
      //my @names;
      DWORD nextnode;
      int dir = 1;
		// �� �������?
      if (dir == 1)
      {
			qsort(&names[0], names.size(), sizeof(Ent),
				(int (__cdecl *)(const void *,const void *))
				& Ent::cmprev);
         if (!nod.right)
				nod.right = this->CreateNode(dwNode) ;
         nextnode = nod.right;
      }else
      {
			qsort(&names[0], names.size(), sizeof(Ent), & Ent::cmp);
         if (!nod.left)
				nod.left = this->CreateNode(dwNode) ;
         nextnode = nod.left;
      }
      //my ($curentry, $retentry);
		//PBL_ENTRYINFO retentry;
		PBLMI_Result ret;
      for(int i = 0; i < names.size(); i ++) {
			if (names[i].offset == -1 ) { 
				ret = this->SeekEntry(names[i]->name, pEntry, TRUE, nextnode);
			} else {
				pent = (PBL_ENT *) (buf.buffer() + names[i].offset);
				PBL_ENTRYINFO curentry;
				curentry.comment_len = pent->comment_len;
				curentry.data_len = pent->data_len;
				curentry.mod_time = pent->creation_time;
				curentry.node = nextnode;
				curentry.data_offset = pent->data_offset;

				ret = this->SeekEntry(names[i].name, &curentry, TRUE, nextnode);
			}
         nod.free_space += strlen(names[i].name) + EntFixedLen + 1;
         names[i].offset = -2;
         nod.ent_count --;

         if(nod.free_space >= 0)
				break;
      }
      //# ���������� ���������� ��� �� ����
      nod.last_offset = 0;
      nod.first_offset = 0;
      fseek(m_Handle, dwNode + NodeEntOffset, SEEK_SET);

      for (int ei = 0; ei < names.size(); ei ++) {
			int i = dir == 1 ? names.size() - ei - 1 : ei;
			if(names[i].offset == -2 )
				continue;
         nod.last_offset = names[i].offset;
         nod.first_offset = nod.last_offset if !nod.first_offset;
         if (names[i].offset == -1)
         {
            my @entrydata =
               unpack "LLLS", substr($buf, $last_offset + 8, 14);
            $retentry = [
               @entrydata,
               $nod,
               sysseek($$me[$Handle], 0, 1) # systell
            ]; 
         }  
         syswrite ($$me[$Handle], 
                   substr($buf, $last_offset, 
                          length($name) + $EntFixedLen + 1)
                  ) or return undef;
      }
      $last_offset += $EntFixedLen if !$last_offset;
      $first_offset += $EntFixedLen if !$first_offset;
      if ($free_space > 0) 
      {
         syswrite ($$me[$Handle], 
                   chr(0) x $free_space
                  ) or return undef;
      }
      
      #��������� ����
      sysseek $$me[$Handle], $nod, 4;
      syswrite( $$me[$Handle], 
                pack ("LLLSSSS", $left, $parent, $right,
                $free_space, $last_offset,
                $ent_count, $first_offset)
              ) or return undef;

      return $retentry;
   }
   
   
*/	
	return PBLMI_ERROR;
}

PBLMI_Result 
PBLMI_PBL::DeleteEntry(PBL_ENTRYINFO *pEntry)
{
	return PBLMI_ERROR;
}

PBLMI_Result 
PBLMI_PBL::ReadEntryData(PBL_ENTRYINFO *pEntry, void * p)
{
	char * pBuf = (char*)p;
	if (!pEntry)
		return PBLMI_ERROR;
	//pf("len: %lu\n", pEntry->data_len);
	//pf("commlen: %lu\n", pEntry->comment_len);
	//pf("len: %lu\n", pEntry->data_len);
	PBL_DAT_HDR hdr;
	DWORD curr = 0;
//	WORD skip = m_bUTF ? pEntry->comment_len * 2 : pEntry->comment_len; 
	hdr.next = pEntry->data_offset; 
	while(hdr.next) {
		fseek(m_Handle, hdr.next, SEEK_SET);
		fread(&hdr, sizeof(hdr), 1, m_Handle);
		if (strncmp(hdr.sign, "DAT*", 4))
			return PBLMI_BADFORMAT;
/*		if (skip) {
			fseek(m_Handle, skip, SEEK_CUR);
			hdr.datalen -= skip;
			skip = 0;
		}
*/
		//pf("readlen: %lu\n", hdr.datalen);
		fread(pBuf + curr, hdr.datalen, 1, m_Handle);
		curr += hdr.datalen;
	}
	//pf("read total: %lu\n", curr);
		
	return PBLMI_OK;
}

BOOL PBLMI_PBL::isUnicode()
{
	return m_bUTF;
}

PBLMI_Result 
PBLMI_PBL::SetEntryTime(PBL_ENTRYINFO *pEntry)
{
	long offset = pEntry->entry_offset;
	offset += (isUnicode() ? sizeof(PBL_ENT_W) : sizeof(PBL_ENT)) - 8;
	fseek(m_Handle, offset, SEEK_SET);
	int ret = fwrite(& pEntry->mod_time, sizeof(pEntry->mod_time), 1, m_Handle);
	//pf("ret: %i", ret);
	//pf("time: %u", pEntry->mod_time);
	return ret == 1 ? PBLMI_OK : PBLMI_ERROR;
}

PBLMI_Result 
PBLMI_PBL::UpdateEntryData
	(
		PBL_ENTRYINFO *pEntry, 
		const BYTE *pData, DWORD dwDataLen, 
		const BYTE *pComments, WORD wComLen
	)
{
	return PBLMI_ERROR;
}


PBLMI_PBL::PBLMI_PBL(PBLMI *aPbLMI, const char *szLibName, BOOL bReadWrite)
{
	m_bIsPBL = FALSE;
	m_Handle = NULL;
	m_bUTF = FALSE;
	m_iPbLMI = aPbLMI;
	m_Handle = fopen(szLibName, bReadWrite ? "rb+" : "rb");
	if (!m_Handle)
		return;
	char buf[4];
	fseek(m_Handle, 0, SEEK_SET);
	if (!fread(buf, 4, 1, m_Handle))
		return;
	if (!strncmp(buf, "HDR*", 4))
	{
		m_StartOffset = 0;
	}else
	{
		fseek(m_Handle, -0x200, SEEK_END);
		if (!fread(buf, 4, 1, m_Handle))
			return;
		if (!strncmp(buf, "TRL*", 4))
		{
			if (!fread(&m_StartOffset, sizeof(m_StartOffset), 1, m_Handle))
				return;
			fseek(m_Handle, m_StartOffset, SEEK_SET);
			if (!fread(buf, 4, 1, m_Handle))
				return;
			if (strncmp(buf, "HDR*", 4))
				return;
		}else
			return;
	} 
	fseek(m_Handle, m_StartOffset + 0x04, SEEK_SET);
	if (!fread(buf, 4, 1, m_Handle))
		return;
	if (*(DWORD*)buf == 0x006f0050)
		m_bUTF = TRUE; // PB10+
	else if (*(DWORD*)buf == 0x65776f50) 
		m_bUTF = FALSE; // PB9-
	else
		return;
	m_bIsPBL = TRUE;
	m_RootNodeOffset = m_bUTF ? 0x600 : 0x400;
}

PBLMI_PBL::~PBLMI_PBL()
{
	if (m_Handle)
		fclose(m_Handle);
}
void 
PBLMI_PBL::Close(void)
{
	delete this;
}


PBLMI_Result PBLMI_PBL::Dir(IPBLMI_Callback *iCallBack)
{
	return ReadNodeEntries(m_StartOffset + m_RootNodeOffset, iCallBack);
}


PBLMI_Result PBLMI_PBL::ReadNodeEntries
(
	DWORD dwNode, 
	IPBLMI_Callback *iCallBack
)
{
	//pf("node: %08X", dwNode);
	if (!dwNode)
		return  PBLMI_OK;
	//!!!debug
	static int n = 0;
	//p("0");
	PBL_NOD nod;
	PBL_ENT *pent;
	PBL_ENT_W *pent_W;
	PBL_ENTRYINFO ei;
	fseek(m_Handle, dwNode, SEEK_SET);
	//p("1");
	if (!fread(&nod, sizeof(nod), 1, m_Handle))
		return PBLMI_BADFORMAT;
	//p("2");
	ByteBuffer data(NodeSize - sizeof(PBL_NOD));
	fseek(m_Handle, dwNode + NodeEntOffset, SEEK_SET);
	if (!fread(data.buffer(), NodeSize - sizeof(PBL_NOD), 1, m_Handle))
		return PBLMI_BADFORMAT;
	//p("3");

	int ent_offset = 0;
	int li_ent;
	for(li_ent = 0;li_ent < nod.ent_count; li_ent ++ )
	{
		n ++;
		//pf("%i", n);
		pent = (PBL_ENT*) (data.buffer() + ent_offset);
		pent_W = (PBL_ENT_W*) pent;
		if(strncmp(pent->sign, "ENT*", 4))
			return PBLMI_BADFORMAT;
		//p("5");
		ei.entry_name = m_iPbLMI->ConvCodePage(
			(char *) (data.buffer() + ent_offset + Get1(EntFixedLen)),
			GetPF(pent,entry_name_len),
			m_bUTF
		);
		if(m_bUTF)
			pent_W->comment_len *= 2;
		ei.comment_len = GetPF(pent, comment_len);
		ei.data_len = GetPF(pent, data_len);
		ei.data_offset = GetPF(pent, data_offset);
		ei.node = dwNode;
		ei.mod_time = GetPF(pent, creation_time.tm);
		ei.entry_offset = dwNode + NodeEntOffset + ent_offset;
		BOOL ret = iCallBack->DirCallback(&ei);
		delete [] ei.entry_name;
		if (!ret)
			return PBLMI_ABORT;  
		ent_offset += Get1(EntFixedLen) + GetPF(pent,entry_name_len);
	}
	//p("6");
	data.FreeBuffer(); 
	//p("7");
	PBLMI_Result ret;
	ret = ReadNodeEntries(nod.left,  iCallBack);
	if( ret != PBLMI_OK )
		return ret;
	ret = ReadNodeEntries(nod.right, iCallBack);
	if( ret != PBLMI_OK )
		return ret;

	return PBLMI_OK;
}




PBLMI::PBLMI() {
	m_TgtCp = PBLMI_ANSI;
//	pf("%i\n", sizeof(PBL_HDR_W));
//	pf("%i\n", sizeof(PBL_HDR));
}
// create library
PBLMI_Result 
PBLMI::CreateLibrary(const char *szLib)
{
	return PBLMI_ERROR;
}

// open library and return IPBLMI_PBL interface to misc. LMI functions
IPBLMI_PBL* 
PBLMI::OpenLibrary(const char *szLib, BOOL bReadWrite)
{
	PBLMI_PBL *iPbl = new PBLMI_PBL(this, szLib, bReadWrite);
	if (!iPbl->m_bIsPBL) {
		delete iPbl;
		return NULL;
	}
	return (IPBLMI_PBL*)iPbl;
}



void 
PBLMI::Release(void)
{
	delete this;
}

// set output encoding for strings
PBLMI_Result 
PBLMI::SetTargetCodePage(PBLMI_CodePage cp){
	m_TgtCp = cp;
	return PBLMI_OK;
}
// get output encoding
PBLMI_CodePage 
PBLMI::GetTargetCodePage() {
	return m_TgtCp;
}

char * 
PBLMI::ConvCodePage(const char * as_Src, 
						  int ai_SrcLen,  
						  BOOL ab_SrcIsWide) {
	int li_Len = ai_SrcLen;
	UINT li_SrcCp = CP_ACP;
	UINT li_TgtCp = MapToCP(m_TgtCp);
	char * ls_Tgt;
	int li_NewLen = 0;
	BOOL lb_UsedDefChar = FALSE;
	if (ab_SrcIsWide && m_TgtCp != PBLMI_WIDE) {
		ls_Tgt = WideToMulti(as_Src, li_Len, li_TgtCp);
	}else if (!ab_SrcIsWide && m_TgtCp == PBLMI_WIDE) {
		ls_Tgt = MultiToWide(as_Src, li_Len, li_SrcCp);
	}else if (!ab_SrcIsWide && li_SrcCp != li_TgtCp) {
		char *ls_tmp = MultiToWide(as_Src, li_Len, li_SrcCp);
		ls_Tgt = WideToMulti(ls_tmp, li_Len*2, li_TgtCp);
		delete [] ls_tmp;
	}else {
		ls_Tgt = new char[li_Len + 1];
		strncpy(ls_Tgt, as_Src, li_Len);
	}
	return ls_Tgt;
}
UINT MapToCP(PBLMI_CodePage cp) {
	switch (cp){
	case PBLMI_UTF8:
		return CP_UTF8;
	case PBLMI_OEM:
		return CP_OEMCP;
	case PBLMI_ANSI:
		return CP_ACP;
	default:
		return 0;
	};
}
char * MultiToWide(const char * as_Src, int ai_Len, UINT ai_Cp) {
	int li_NewLen = MultiByteToWideChar(
		ai_Cp,
		MB_PRECOMPOSED,
		(LPCSTR) as_Src,
		ai_Len , // incl 0
		NULL, 
		0 // return buf size in wchar's
	);
	char *ls_Tgt = new char[li_NewLen * 2 + 2];
	int ret = MultiByteToWideChar(
		ai_Cp,
		MB_PRECOMPOSED,
		(LPCSTR) as_Src,
		ai_Len, // incl 0
		(LPWSTR)ls_Tgt, 
		li_NewLen
	);
	if (ret != li_NewLen) {
		PrintLastError();
		
	}
	ls_Tgt[li_NewLen * 2 + 0] = '\0';
	ls_Tgt[li_NewLen * 2 + 1] = '\0';
	return ls_Tgt;

}
char * WideToMulti(const char * as_Src, int ai_Len, UINT ai_Cp) {
	int li_NewLen = WideCharToMultiByte(
		ai_Cp,
		0, //WC_DEFAULTCHAR,
		(LPCWSTR) as_Src,
		ai_Len / 2, // incl 0
		NULL, 
		0, // return buf size in bytes
		NULL, //"?", // def char
		NULL // &lb_UsedDefChar
	);

	if (li_NewLen == 0) {
		PrintLastError();
		exit(1);
	}
	char *ls_Tgt = new char[li_NewLen];
	WideCharToMultiByte(
		ai_Cp,
		0, //WC_DEFAULTCHAR,
		(LPCWSTR) as_Src,
		ai_Len / 2, // incl 0
		(LPSTR)ls_Tgt, 
		li_NewLen,
		NULL, //"?", // def char
		NULL  //&lb_UsedDefChar
	);
	return ls_Tgt;
}
// global IPBLMI generator
extern "C"
__declspec(dllexport)
IPBLMI* 
PBLMI_GetInterface()
{
   return new PBLMI();
}


void PrintLastError() {
	char errs[80];
	FormatMessage(
		FORMAT_MESSAGE_FROM_SYSTEM,
		NULL,
		GetLastError(),
		0,
		(LPTSTR)errs,
		sizeof(errs),
		NULL
	);
	printf("LastError: '%s'\n", errs);
}