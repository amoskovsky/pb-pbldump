// PblDump.h: interface for the PblDump class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PBLDUMP_H__FD0B4158_3055_4249_883C_DC6FB2D1197B__INCLUDED_)
#define AFX_PBLDUMP_H__FD0B4158_3055_4249_883C_DC6FB2D1197B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <stdio.h>
#include <string.h>
#include "pblsdk.h"
#include <time.h>
#include "classes.h"


class PblDump : public IPBLMI_Callback 
{
	IPBLMI* m_iPbLMI;
	IPBLMI_PBL * m_iPbl;
	int m_nEntCount;
	enum EntryType {SOURCE =0, PCODE = 1, RESOURCE = 2};
	enum DirType {ListDir, ExportDir};
	enum ExportCPType {ECP_AUTO, ECP_ANSI, ECP_UNICODE};
	char * TypePrefix[3];
	DirType m_dirType;
	BOOL m_bExportPcode; // *.* exports pcode?
	ExportCPType m_iExportCP; 
public:
	PblDump();
	virtual ~PblDump();
	int main(int argc, char ** argv);
	void  logo();
	void  usage();
	BOOL DirCallback(PBL_ENTRYINFO *pEntry);
	EntryType getEntryType( const char * szEntryName); 
	int exportEntries(int e_num, char * e_list []);
	int exportEntry(char * e_name);
	int exportEntry(PBL_ENTRYINFO *pEntry, char * e_name);
	int init(const char * szPbl);
	int cleanup();
	int listPBL();
	int FindEndOfDir(const char *szPath);
	int writeBinaryData(FILE *f, PBL_ENTRYINFO *pEntry, char * e_name, char * binName, BOOL isUTF);
	int convertToUTF(ByteBuffer& buf, WORD &comm_len, DWORD &data_len);
	int convertToANSI(ByteBuffer& buf, WORD &comm_len, DWORD &data_len, BOOL &bHexUsed);
};

#define u_fprintf(f,t) \
	if (isUTF) { \
		fwprintf(f, L##t); \
	} \
	else { \
		fprintf(f, t); \
	}
#define u_fprintf1(f,t, a1) \
	if (isUTF) { \
		fwprintf(f, L##t, a1); \
	} \
	else { \
		fprintf(f, t, a1); \
	}
#define u_fprintf2(f,t, a1, a2) \
	if (isUTF) { \
		fwprintf(f, L##t, a1, a2); \
	} \
	else { \
		fprintf(f, t, a1, a2); \
	}
#define u_C(c) (isUTF ? L##c : c)
#define u_T(t) (isUTF ? L##t : t)

#endif // !defined(AFX_PBLDUMP_H__FD0B4158_3055_4249_883C_DC6FB2D1197B__INCLUDED_)
