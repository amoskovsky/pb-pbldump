#include "pblsdk.h"
#include <stdio.h>
#include "debug.h"
#include <time.h>


/**
 * @return 
 *	size of entry
 * or negative error code
 */
extern "C"
int PBLMI_ExportEntry(
								const char * szPBL, 
								const char * szEntry, 
								char *buf, int bufSize, 
								int *pCommSize, 
								time_t * pEntryTime
							) 
{
   IPBLMI* iPbLMI = PBLMI_GetInterface();
   if (!iPbLMI) {
      return -1;
   }
   IPBLMI_PBL * iPbl = iPbLMI->OpenLibrary(szPBL, FALSE);
   if (!iPbl) {
		iPbLMI->Release();
      return -2;
   }
	PBLMI_Result ret;	
   
	PBL_ENTRYINFO entry;
	ret = iPbl->SeekEntry(szEntry, &entry, FALSE);
   if (ret != PBLMI_OK) {
		iPbl->Close();
		iPbLMI->Release();
      return 0;
   }
	if (!bufSize) {
		iPbl->Close();
		iPbLMI->Release();
		if (pCommSize)
			*pCommSize = entry.comment_len;
		if (pEntryTime)
			*pEntryTime = entry.mod_time;
		return entry.data_len;
	}
	if (bufSize < (int)entry.data_len) {
		iPbl->Close();
		iPbLMI->Release();
		return -3;
	}
	
	ret = iPbl->ReadEntryData(&entry, buf);
   if (ret != PBLMI_OK) {
		iPbl->Close();
		iPbLMI->Release();
      return -4;
   }
   iPbl->Close();
   iPbLMI->Release();
	if (pCommSize)
		*pCommSize = entry.comment_len;
	if (pEntryTime)
		*pEntryTime = entry.mod_time;
   return entry.data_len;   
}


extern "C"
int PBLMI_SetEntryTime(
								const char * szPBL, 
								const char * szEntry, 
								time_t entryTime
							) 
{
   IPBLMI* iPbLMI = PBLMI_GetInterface();
   if (!iPbLMI) {
      return -1;
   }
   IPBLMI_PBL * iPbl = iPbLMI->OpenLibrary(szPBL, TRUE); // for RW
   if (!iPbl) {
		iPbLMI->Release();
      return -2;
   }
	PBLMI_Result ret;	
   
	PBL_ENTRYINFO entry;
	ret = iPbl->SeekEntry(szEntry, &entry, FALSE);
   if (ret != PBLMI_OK) {
		iPbl->Close();
		iPbLMI->Release();
      return 0;
   }
	entry.mod_time = entryTime;
	iPbl->SetEntryTime(&entry);
   iPbl->Close();
   iPbLMI->Release();
   return 1;   
}


