#include "pblsdk.h"
#include <stdio.h>
#include "debug.h"

struct MyCallback : public IPBLMI_Callback {
   MyCallback() {}
   BOOL DirCallback(PBL_ENTRYINFO *pEntry) { 
      printf("entry: %s\n", pEntry->entry_name);
      return TRUE;
   }
};

int main1() {
   //char *szPBL = "../test/old.pbl";
	char *szPBL = "../test/bigold.pbl";
	//char *szPBL = "../test/genapp_ci.pbl";

   printf("PBLMI_GetInterface\n");
   IPBLMI* iPbLMI = PBLMI_GetInterface();
   if (!iPbLMI) {
      printf("PBLMI_GetInterface failed\n");
      return 1;
   }
	iPbLMI->SetTargetCodePage(PBLMI_ANSI);

   printf("OpenPBL: %s\n", szPBL);
   IPBLMI_PBL * iPbl = iPbLMI->OpenLibrary(szPBL, FALSE);
   if (!iPbl) {
      printf("iPbLMI->OpenLibrary failed\n");
      return 1;
   }
	PBLMI_Result ret;	
   printf("List PBL\n");
   ret = iPbl->Dir(new MyCallback());
   if (ret != PBLMI_OK) {
      printf("iPbl->Dir failed\n");
      return 1;
   }

	printf("Seek Entry\n");
   
	PBL_ENTRYINFO entry;
	//char * entry_name = "d_rep_1.srd";
	//char * entry_name = "m_genapp_main.srm";
	char * entry_name = "uo_setting.sru";	
	ret = iPbl->SeekEntry(entry_name, &entry, FALSE);
   if (ret != PBLMI_OK) {
      printf("iPbl->SeekEntry failed\n");
      return 1;
   }
	
	char *buf = new char[entry.data_len +1];
	ret = iPbl->ReadEntryData(&entry, buf);
   if (ret != PBLMI_OK) {
      printf("iPbl->ReadEntryData failed\n");
      return 1;
   }
	FILE *f = fopen("dump.bin", "wb+");
	fwrite(buf, entry.data_len, 1, f);
	fclose(f);
	
   p("in main 10");
   
   printf("Close PBL\n");
   iPbl->Close();

   printf("Release iPbLMI\n");
   iPbLMI->Release();
   return 0;   
}

