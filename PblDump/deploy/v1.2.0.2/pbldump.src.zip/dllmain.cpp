#include "dllmain.h"

BOOL APIENTRY DllMain(HANDLE hModule,
                DWORD ul_reason_for_all,
                LPVOID lpReserved
              )
{
   switch(ul_reason_for_all)
   {
      case DLL_PROCESS_ATTACH:
      case DLL_THREAD_ATTACH:
      case DLL_THREAD_DETACH:
      case DLL_PROCESS_DETACH:
         break;
   }

   return TRUE;

}




