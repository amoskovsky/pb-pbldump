#ifndef _debug_h_
#define _debug_h_

//#ifdef DEBUG
#define p(a) printf("%s\n", a)
#define pf(a,b) printf(a "\n", b)
//#else
//#define p(a)
//#endif

#endif