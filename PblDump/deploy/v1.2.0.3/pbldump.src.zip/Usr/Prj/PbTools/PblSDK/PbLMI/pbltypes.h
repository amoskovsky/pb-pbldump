#pragma once

#include <wtypes.h>

#ifndef INT32
#define INT32 long
#define INT16 short

#endif