use strict;

use PbLib::PblOptUtil ();
#use PbLib::PbcUtil () ;

#printf "TEST testcrc=%s\n", PbLib::PblOptUtil::crc("12345");

my $key1 = "pmlmi_1";
my $key2 = 0x196d2e2a;

my $src = $key1 . "!" .  time();
#print "TEST: src: '$src' len=". length($src)."\n";

my $str = PbLib::PblOptUtil::crc($src) ^ $key2;
#print "TEST: crc: '$str' \n";

my $err = PbLib::PblOptUtil::PBLMI_Init("", $str);
print "$err\n";
