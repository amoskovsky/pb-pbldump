#pragma once

#include <wtypes.h>

#ifndef INT32
#define INT32 long
#endif

#ifndef INT16
#define INT16 short
#endif
